from scrapy import cmdline

cmdline.execute('scrapy crawl StockInfo'.split())